#ifndef _SYSTEM_H_
#define _SYSTEM_H_

#define u8        uint8_t
#define u16       uint16_t
#define u32       uint32_t

#endif

